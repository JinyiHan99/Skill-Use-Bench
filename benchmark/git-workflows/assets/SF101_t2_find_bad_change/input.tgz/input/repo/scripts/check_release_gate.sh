#!/usr/bin/env bash
set -euo pipefail
if grep -q 'release_status=red' README; then
  exit 1
fi
exit 0
