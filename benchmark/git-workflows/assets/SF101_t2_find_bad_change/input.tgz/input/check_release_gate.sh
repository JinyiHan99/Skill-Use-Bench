#!/usr/bin/env bash
set -euo pipefail
repo_dir="${1:-.}"
if grep -q 'release_status=red' "$repo_dir/README"; then
  exit 1
fi
exit 0
